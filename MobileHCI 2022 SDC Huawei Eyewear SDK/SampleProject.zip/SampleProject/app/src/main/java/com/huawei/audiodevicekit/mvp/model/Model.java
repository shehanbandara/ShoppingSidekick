package com.huawei.audiodevicekit.mvp.model;

/**
 * Created by Felix on 2016/10/18.
 * <p>
 * Mvp模式中，M的高层接口模块
 */
public interface Model {
}
